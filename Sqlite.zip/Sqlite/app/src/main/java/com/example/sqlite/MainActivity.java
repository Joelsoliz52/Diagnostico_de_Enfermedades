package com.example.sqlite;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public EditText textNombre;
    public Button btnAgregar;
    public TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textNombre =(EditText)findViewById(R.id.editNombre);
        btnAgregar =(Button)findViewById(R.id.btnAgregar);
        resultado = findViewById(R.id.resultado);

        btnAgregar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                DataBaseAccess dataBaseAccess = DataBaseAccess.getInstance(getApplicationContext());
                dataBaseAccess.open();
                String n = textNombre.getText().toString();
                String descripcion = dataBaseAccess.getAdrress(n);
                resultado.setText(descripcion);
                dataBaseAccess.close();
            }
        });

    }

}
