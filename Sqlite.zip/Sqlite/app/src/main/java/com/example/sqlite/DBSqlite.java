package com.example.sqlite;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

public class DBSqlite extends SQLiteAssetHelper {
    private static final String NOMBRE_DB = "DBMS enfermedad_sintoma V2.db";
    private static final int VERSION_DB = 3;


    public DBSqlite(Context context) {
        super(context, NOMBRE_DB, null,VERSION_DB);
    }

}
