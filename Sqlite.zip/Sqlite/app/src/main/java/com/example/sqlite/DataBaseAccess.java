package com.example.sqlite;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseAccess {
    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase db;
    private static DataBaseAccess instance;
    Cursor c = null;

    private DataBaseAccess(Context context){
        this.openHelper = new DBSqlite(context);
    }

    public static DataBaseAccess getInstance(Context context){
        if(instance == null){
            instance = new DataBaseAccess(context);
        }
        return instance;
    }

    public void open(){
        this.db = openHelper.getWritableDatabase();
    }

    public void close(){
        if(db!=null){
            this.db.close();
        }
    }

    public String getAdrress(String name){
        c = db.rawQuery("select DESCRIPCION_ENFERMEDAD from enfermedad where upper(NOMBRE_ENFERMEDAD) = upper('"+name+"')",new String[]{});
        StringBuffer buffer = new StringBuffer();
        while(c.moveToNext()){
            String descripcion = c.getString(0);
            buffer.append(""+descripcion);
        }
        return  buffer.toString();
    }
}
